package com.example.urja_buddy

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
