import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/appliance.dart';
import '../theme/urja_theme.dart';
import '../widgets/dashboard_widgets.dart';
import '../services/ai_service.dart';
import '../services/energy_service.dart';
import '../providers/energy_provider.dart';

class ApplianceManagerCard extends ConsumerStatefulWidget {
  const ApplianceManagerCard({super.key});

  @override
  ConsumerState<ApplianceManagerCard> createState() => _ApplianceManagerCardState();
}

class _ApplianceManagerCardState extends ConsumerState<ApplianceManagerCard> {
  List<Appliance> _appliances = [];
  late Box _appliancesBox;
  bool _isLoading = true;
  String _dailyTip = 'Loading AI Tip...';
  final AIService _aiService = AIService();
  final EnergyService _energyService = EnergyService();

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    try {
      _appliancesBox = await Hive.openBox('appliances');

      if (mounted) {
        setState(() {
          if (_appliancesBox.isEmpty) {
            // Default Appliances
            _appliances = [
              Appliance(id: '1', name: 'Air Conditioner', wattage: 2000, hoursPerDay: 6),
              Appliance(id: '2', name: 'Refrigerator', wattage: 150, hoursPerDay: 24),
              Appliance(id: '3', name: 'LED Lights (10x)', wattage: 100, hoursPerDay: 8),
            ];
            _saveAppliances(); // Save defaults
          } else {
            _appliances = _appliancesBox.values.map((e) => Appliance.fromMap(Map<String, dynamic>.from(e))).toList();
          }
          _isLoading = false;
        });
      }
      
      _fetchAiTip();
    } catch (e) {
      debugPrint("Error loading appliance data: $e");
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _fetchAiTip() async {
    try {
      final tip = await _aiService.getTipOfTheDay();
      if (mounted) {
        setState(() {
          _dailyTip = tip;
        });
      }
    } catch (e) {
      debugPrint("AI Tip Error: $e");
    }
  }

  void _saveAppliances() {
    _appliancesBox.clear();
    for (var app in _appliances) {
      _appliancesBox.add(app.toMap());
    }
  }

  void _addAppliance(String name, double watts, double hours) {
    setState(() {
      _appliances.add(Appliance(
        id: DateTime.now().toString(),
        name: name,
        wattage: watts,
        hoursPerDay: hours,
      ));
      _saveAppliances();
    });
  }

  void _editAppliance(int index, String name, double watts, double hours) {
    setState(() {
      _appliances[index] = Appliance(
        id: _appliances[index].id,
        name: name,
        wattage: watts,
        hoursPerDay: hours,
      );
      _saveAppliances();
    });
  }

  void _deleteAppliance(int index) {
    setState(() {
      _appliances.removeAt(index);
      _saveAppliances();
    });
  }

  double get _totalApplianceCost => _appliances.fold(0, (sum, item) => sum + item.monthlyCost);

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator(color: UrjaTheme.primaryGreen));
    }

    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Appliance Manager', style: Theme.of(context).textTheme.titleLarge),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: UrjaTheme.glassBorder,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      'Total: ₹${_totalApplianceCost.toStringAsFixed(2)}',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: UrjaTheme.primaryGreen,
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  IconButton(
                    icon: const Icon(Icons.add_circle, color: UrjaTheme.primaryGreen),
                    onPressed: () => _showApplianceDialog(context),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 24),
          if (_appliances.isEmpty)
            const Text('No appliances added.', style: TextStyle(color: UrjaTheme.textSecondary))
          else
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _appliances.length,
              separatorBuilder: (context, index) => const Divider(color: UrjaTheme.glassBorder, height: 32),
              itemBuilder: (context, index) {
                final app = _appliances[index];
                return InkWell(
                  onTap: () => _showApplianceDialog(context, appliance: app, index: index),
                  child: _buildApplianceItem(
                    context, 
                    app.name, 
                    '${app.wattage.toInt()}W', 
                    '${app.hoursPerDay}h/day', 
                    '₹${app.monthlyCost.toStringAsFixed(2)}', 
                    Icons.electrical_services,
                    isOverBudget: app.monthlyCost > 20, // Example threshold
                  ),
                );
              },
            ),
          
          const SizedBox(height: 24),
          Row(
            children: [
              const Icon(Icons.auto_awesome, color: UrjaTheme.primaryGreen),
              const SizedBox(width: 8),
              Text('AI Tip of the Day', style: Theme.of(context).textTheme.titleMedium),
            ],
          ),
          const SizedBox(height: 16),
          _buildSmartTip(context, '1', _dailyTip),
        ],
      ),
    );
  }

  Widget _buildApplianceItem(BuildContext context, String name, String power, String usage, String cost, IconData icon, {bool isOverBudget = false}) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: UrjaTheme.glassBorder.withValues(alpha: 0.5),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, color: UrjaTheme.textPrimary),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
                  if (isOverBudget) ...[
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: UrjaTheme.errorRed.withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: const Text(
                        'High Cost',
                        style: TextStyle(color: UrjaTheme.errorRed, fontSize: 10, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ],
              ),
              const SizedBox(height: 4),
              Text('$power • $usage', style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
        ),
        Text(
          cost,
          style: const TextStyle(fontWeight: FontWeight.bold, color: UrjaTheme.textPrimary),
        ),
      ],
    );
  }

  Widget _buildSmartTip(BuildContext context, String number, String text) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 20,
          height: 20,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: UrjaTheme.primaryGreen.withValues(alpha: 0.2),
            shape: BoxShape.circle,
          ),
          child: Text(
            number,
            style: const TextStyle(color: UrjaTheme.primaryGreen, fontSize: 12, fontWeight: FontWeight.bold),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            text,
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ),
      ],
    );
  }

  void _showApplianceDialog(BuildContext context, {Appliance? appliance, int? index}) {
    final nameController = TextEditingController(text: appliance?.name ?? '');
    final wattsController = TextEditingController(text: appliance?.wattage.toString() ?? '');
    final hoursController = TextEditingController(text: appliance?.hoursPerDay.toString() ?? '');
    bool isSmartConnecting = false;

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              backgroundColor: UrjaTheme.cardBackground,
              title: Text(appliance == null ? 'Add Appliance' : 'Edit Appliance', style: const TextStyle(color: UrjaTheme.textPrimary)),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: nameController,
                    style: const TextStyle(color: UrjaTheme.textPrimary),
                    decoration: const InputDecoration(
                      labelText: 'Name',
                      labelStyle: TextStyle(color: UrjaTheme.textSecondary),
                      enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: UrjaTheme.glassBorder)),
                      focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: UrjaTheme.primaryGreen)),
                    ),
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: wattsController,
                          keyboardType: TextInputType.number,
                          style: const TextStyle(color: UrjaTheme.textPrimary),
                          decoration: const InputDecoration(
                            labelText: 'Wattage (W)',
                            labelStyle: TextStyle(color: UrjaTheme.textSecondary),
                            enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: UrjaTheme.glassBorder)),
                            focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: UrjaTheme.primaryGreen)),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      // Smart Plug Button
                      IconButton(
                        icon: isSmartConnecting 
                          ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) 
                          : const Icon(Icons.wifi, color: UrjaTheme.primaryGreen),
                        tooltip: 'Connect Smart Device',
                        onPressed: isSmartConnecting ? null : () async {
                          setState(() => isSmartConnecting = true);
                          try {
                            final watts = await _energyService.connectSmartDevice(nameController.text);
                            wattsController.text = watts.toStringAsFixed(0);
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Connected! Live Wattage: ${watts.toInt()}W')));
                            }
                          } finally {
                            if (context.mounted) setState(() => isSmartConnecting = false);
                          }
                        },
                      ),
                    ],
                  ),
                  TextField(
                    controller: hoursController,
                    keyboardType: TextInputType.number,
                    style: const TextStyle(color: UrjaTheme.textPrimary),
                    decoration: const InputDecoration(
                      labelText: 'Hours per Day',
                      labelStyle: TextStyle(color: UrjaTheme.textSecondary),
                      enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: UrjaTheme.glassBorder)),
                      focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: UrjaTheme.primaryGreen)),
                    ),
                  ),
                ],
              ),
              actions: [
                if (appliance != null)
                  TextButton(
                    onPressed: () {
                      _deleteAppliance(index!);
                      Navigator.pop(context);
                    },
                    child: const Text('Delete', style: TextStyle(color: UrjaTheme.errorRed)),
                  ),
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Cancel', style: TextStyle(color: UrjaTheme.textSecondary)),
                ),
                ElevatedButton(
                  onPressed: () async {
                    final name = nameController.text;
                    final watts = double.tryParse(wattsController.text);
                    final hours = double.tryParse(hoursController.text);

                    if (name.isNotEmpty && watts != null && hours != null) {
                      if (appliance == null) {
                        // Create new appliance object
                        final newApp = Appliance(
                          id: DateTime.now().millisecondsSinceEpoch.toString(),
                          name: name,
                          wattage: watts,
                          hoursPerDay: hours,
                        );

                        try {
                          // 1. Sync to Firebase
                          await _energyService.addAppliance(newApp);

                          // 2. Update Global State (Riverpod)
                          ref.invalidate(energyProvider);

                          // 3. Update Local State (Hive/UI)
                          if (mounted) {
                            setState(() {
                              _appliances.add(newApp);
                              _saveAppliances();
                            });
                            
                            Navigator.pop(context);
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('Appliance added & Dashboard updated!'),
                                backgroundColor: UrjaTheme.primaryGreen,
                              ),
                            );
                          }
                        } catch (e) {
                          if (mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('Error: $e'), backgroundColor: UrjaTheme.errorRed),
                            );
                          }
                        }
                      } else {
                        _editAppliance(index!, name, watts, hours);
                        Navigator.pop(context);
                      }
                    }
                  },
                  style: ElevatedButton.styleFrom(backgroundColor: UrjaTheme.primaryGreen),
                  child: const Text('Save', style: TextStyle(color: Colors.white)),
                ),
              ],
            );
          }
        );
      },
    );
  }
}
