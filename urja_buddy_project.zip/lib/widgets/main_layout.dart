import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import '../theme/urja_theme.dart';

class MainLayout extends StatefulWidget {
  final Widget child;
  final int currentIndex;
  final Function(int) onIndexChanged;

  const MainLayout({
    super.key,
    required this.child,
    required this.currentIndex,
    required this.onIndexChanged,
  });

  @override
  State<MainLayout> createState() => _MainLayoutState();
}

class _MainLayoutState extends State<MainLayout> {
  @override
  Widget build(BuildContext context) {
    final isDesktop = MediaQuery.of(context).size.width > 1024;

    return Scaffold(
      backgroundColor: UrjaTheme.darkBackground,
      extendBodyBehindAppBar: true,
      body: Stack(
        children: [
          // Background Gradient Mesh
          Positioned(
            top: -100,
            left: -100,
            child: Container(
              width: 500,
              height: 500,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    UrjaTheme.primaryGreen.withValues(alpha: 0.15),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            bottom: -100,
            right: -100,
            child: Container(
              width: 500,
              height: 500,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    const Color(0xFF0EA5E9).withValues(alpha: 0.15), // Sky Blue
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          
          // Main Layout
          Row(
            children: [
              if (isDesktop) _buildSidebar(context),
              Expanded(
                child: Column(
                  children: [
                    _buildHeader(context, !isDesktop),
                    Expanded(
                      child: widget.child,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      drawer: isDesktop ? null : Drawer(
        backgroundColor: UrjaTheme.darkBackground,
        child: _buildSidebarContent(context),
      ),
    );
  }

  Widget _buildHeader(BuildContext context, bool showMenu) {
    return ClipRRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
          decoration: BoxDecoration(
            border: Border(bottom: BorderSide(color: UrjaTheme.glassBorder)),
            color: UrjaTheme.darkBackground.withValues(alpha: 0.7),
          ),
          child: Row(
            children: [
              if (showMenu)
                IconButton(
                  icon: const Icon(Icons.menu, color: UrjaTheme.textSecondary),
                  onPressed: () => Scaffold.of(context).openDrawer(),
                ),
              if (showMenu) const SizedBox(width: 16),
              Text(
                'Dashboard',
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontSize: 24),
              ),
              const Spacer(),
              _buildIconButton(Icons.search, () {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Search is coming in v2.0')));
              }),
              const SizedBox(width: 12),
              _buildIconButton(Icons.notifications_outlined, () {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('No new notifications')));
              }),
              const SizedBox(width: 16),
              Container(
                height: 32,
                width: 1,
                color: UrjaTheme.glassBorder,
              ),
              const SizedBox(width: 16),
              const CircleAvatar(
                radius: 18,
                backgroundColor: UrjaTheme.primaryGreen,
                child: Text('U', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildIconButton(IconData icon, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      focusNode: FocusNode(skipTraversal: true),
      hoverColor: Colors.transparent,
      highlightColor: Colors.transparent,
      splashColor: Colors.transparent,
      focusColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.05),
          shape: BoxShape.circle,
          border: Border.all(color: UrjaTheme.glassBorder),
        ),
        child: Icon(icon, color: UrjaTheme.textSecondary, size: 20),
      ),
    );
  }

  Widget _buildSidebar(BuildContext context) {
    return Container(
      width: 260,
      decoration: BoxDecoration(
        color: UrjaTheme.cardBackground.withValues(alpha: 0.5),
        border: Border(right: BorderSide(color: UrjaTheme.glassBorder)),
      ),
      child: _buildSidebarContent(context),
    );
  }

  Widget _buildSidebarContent(BuildContext context) {
    return Theme(
      data: Theme.of(context).copyWith(
        splashFactory: NoSplash.splashFactory, // Disable splash globally for sidebar
        highlightColor: Colors.transparent,
        splashColor: Colors.transparent,
        hoverColor: Colors.transparent,
        focusColor: Colors.transparent,
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 24),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center, // Center logo and text
              children: [
                // Logo Replacement (Image Asset)
                Container(
                  width: 50, // Constrained size (40-50)
                  height: 50,
                  alignment: Alignment.center,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.transparent, // Transparent background
                  ),
                  child: Image.asset(
                    'assets/images/logo_black.png', // New black logo
                    fit: BoxFit.contain,
                  ),
                ),
              const SizedBox(width: 12),
              Text(
                'Urja Buddy',
                style: GoogleFonts.poppins(
                  textStyle: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontSize: 22,
                    fontWeight: FontWeight.w900, // Extra Bold
                    letterSpacing: -0.5,
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        _buildNavItem(0, Icons.grid_view_rounded, 'Dashboard'),
        _buildNavItem(1, Icons.pie_chart_rounded, 'Analytics'),
        _buildNavItem(2, Icons.bolt_rounded, 'Smart Alerts'),
        _buildNavItem(3, Icons.people_rounded, 'Community'),
        const Spacer(),
        _buildNavItem(4, Icons.settings_rounded, 'Settings'),
        const SizedBox(height: 32),
      ],
    ),
  );
  }

  Widget _buildNavItem(int index, IconData icon, String label) {
    final isSelected = widget.currentIndex == index;
    return InkWell(
      onTap: () => widget.onIndexChanged(index),
      focusNode: FocusNode(skipTraversal: true),
      hoverColor: Colors.transparent,
      highlightColor: Colors.transparent,
      splashColor: Colors.transparent,
      focusColor: Colors.transparent,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: isSelected ? UrjaTheme.primaryGreen.withValues(alpha: 0.1) : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
          border: isSelected ? Border.all(color: UrjaTheme.primaryGreen.withValues(alpha: 0.2)) : null,
        ),
        child: Row(
          children: [
            Icon(
              icon,
              color: isSelected ? UrjaTheme.primaryGreen : UrjaTheme.textSecondary,
              size: 20,
            ),
            const SizedBox(width: 12),
            Text(
              label,
              style: TextStyle(
                color: isSelected ? UrjaTheme.textPrimary : UrjaTheme.textSecondary,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
