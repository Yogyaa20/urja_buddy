import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'dart:ui';
import '../theme/urja_theme.dart';

// 1. Reusable Glass Card Component
class GlassCard extends StatefulWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final VoidCallback? onTap;

  const GlassCard({super.key, required this.child, this.padding, this.onTap});

  @override
  State<GlassCard> createState() => _GlassCardState();
}

class _GlassCardState extends State<GlassCard> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    Widget content = AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      transform: Matrix4.translationValues(0.0, _isHovered ? -4.0 : 0.0, 0.0),
      decoration: BoxDecoration(
        color: UrjaTheme.cardBackground,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: UrjaTheme.glassBorder, width: 1),
        boxShadow: _isHovered
            ? [
                BoxShadow(
                  color: UrjaTheme.primaryGreen.withValues(alpha: 0.1),
                  blurRadius: 24,
                  offset: const Offset(0, 8),
                )
              ]
            : [],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Padding(
            padding: widget.padding ?? const EdgeInsets.all(24),
            child: widget.child,
          ),
        ),
      ),
    );

    if (widget.onTap != null) {
      return MouseRegion(
        onEnter: (_) => setState(() => _isHovered = true),
        onExit: (_) => setState(() => _isHovered = false),
        child: GestureDetector(
          onTap: widget.onTap,
          behavior: HitTestBehavior.opaque,
          child: content,
        ),
      );
    } else {
      return MouseRegion(
        onEnter: (_) => setState(() => _isHovered = true),
        onExit: (_) => setState(() => _isHovered = false),
        child: content,
      );
    }
  }
}

// 2. Updated Metric Card
class MetricCard extends StatelessWidget {
  final String title;
  final String value;
  final String subValue;
  final bool isPositive;
  final IconData icon;

  const MetricCard({
    super.key,
    required this.title,
    required this.value,
    required this.subValue,
    required this.isPositive,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      child: SizedBox(
        height: 140, // Fixed height for consistency
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween, // Distribute space
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(title, style: Theme.of(context).textTheme.bodyMedium),
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: UrjaTheme.primaryGreen.withValues(alpha: 0.1),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(icon, color: UrjaTheme.primaryGreen, size: 20),
                ),
              ],
            ),
            // Centered Value
            Expanded(
              child: Center(
                child: Text(
                  value,
                  style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                        fontSize: 32,
                        fontWeight: FontWeight.w700,
                      ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// 3. Consumption Trend Chart (Line Chart with Gradient)
class ConsumptionTrendChart extends StatefulWidget {
  final List<double> weeklyData;
  final List<double>? monthlyData; 
  final List<double>? yearlyData;
  final double? todayTotalOverride; // New parameter to force today's total

  const ConsumptionTrendChart({
    super.key, 
    required this.weeklyData, 
    this.monthlyData,
    this.yearlyData,
    this.todayTotalOverride,
  });

  @override
  State<ConsumptionTrendChart> createState() => _ConsumptionTrendChartState();
}

class _ConsumptionTrendChartState extends State<ConsumptionTrendChart> {
  String _selectedPeriod = 'Weekly';

  @override
  Widget build(BuildContext context) {
    // Determine which data to show
    final isMonthly = _selectedPeriod == 'Monthly';
    final isYearly = _selectedPeriod == 'Yearly';
    
    // Create a mutable copy of the data
    List<double> currentData = isYearly 
        ? List.from(widget.yearlyData ?? [])
        : isMonthly 
            ? List.from(widget.monthlyData ?? []) 
            : List.from(widget.weeklyData);

    // FIX: Update today's usage in Monthly/Yearly views if needed
    if (!isMonthly && !isYearly && widget.todayTotalOverride != null && currentData.isNotEmpty) {
       // Find today's index (0=Mon ... 6=Sun)
       final todayIndex = DateTime.now().weekday - 1;
       if (todayIndex >= 0 && todayIndex < currentData.length) {
         currentData[todayIndex] = widget.todayTotalOverride!;
       }
    } else if (isMonthly && widget.todayTotalOverride != null && currentData.isNotEmpty) {
       final currentMonthIndex = DateTime.now().month - 1;
       if (currentMonthIndex >= 0 && currentMonthIndex < currentData.length) {
          // If the aggregated monthly total is LESS than today's usage (which is impossible unless data is missing),
          // update it to at least match today's usage.
          if (currentData[currentMonthIndex] < widget.todayTotalOverride!) {
             currentData[currentMonthIndex] = widget.todayTotalOverride!; 
          }
       }
    } else if (isYearly && widget.todayTotalOverride != null && currentData.isNotEmpty) {
       // Current year is the last index (4)
       if (currentData.last < widget.todayTotalOverride!) {
          currentData[currentData.length - 1] = widget.todayTotalOverride!;
       }
    }
    
    // Safety check: ensure we have data or default to zeros
    final displayData = currentData.isEmpty 
        ? List.filled(isYearly ? 5 : (isMonthly ? 12 : 7), 0.0) 
        : currentData;

    final maxX = (isYearly ? 4 : (isMonthly ? 11 : 6)).toDouble();

    // Dynamic Y max based on data peak + padding
    final maxValue = displayData.reduce((curr, next) => curr > next ? curr : next);
    // Ensure min Y is at least 20 or 1.5x of today's usage to prevent flat lines
    final minMaxY = (widget.todayTotalOverride ?? 0) * 1.5;
    final calculatedMaxY = maxValue * 1.2;
    final maxY = (calculatedMaxY > minMaxY ? calculatedMaxY : minMaxY).clamp(20.0, 50000.0);

    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Consumption Trend', style: Theme.of(context).textTheme.titleLarge),
              Row(
                children: ['Weekly', 'Monthly', 'Yearly'].map((period) {
                  final isSelected = _selectedPeriod == period;
                  return GestureDetector(
                    onTap: () => setState(() => _selectedPeriod = period),
                    child: Container(
                      margin: const EdgeInsets.only(left: 8),
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: isSelected ? UrjaTheme.primaryGreen : Colors.transparent,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: isSelected ? UrjaTheme.primaryGreen : UrjaTheme.glassBorder,
                        ),
                      ),
                      child: Text(
                        period,
                        style: TextStyle(
                          color: isSelected ? Colors.white : UrjaTheme.textSecondary,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ],
          ),
          const SizedBox(height: 24),
          SizedBox(
            height: 250,
            child: displayData.every((e) => e == 0)
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.query_stats, size: 48, color: UrjaTheme.textSecondary),
                        const SizedBox(height: 16),
                        Text(
                          'No ${_selectedPeriod.toLowerCase()} consumption data',
                          style: const TextStyle(color: UrjaTheme.textSecondary),
                        ),
                      ],
                    ),
                  )
                : LineChart(
                    LineChartData(
                      lineTouchData: LineTouchData(
                        touchTooltipData: LineTouchTooltipData(
                          // tooltipBgColor: UrjaTheme.cardBackground, // Deprecated in newer fl_chart
                          getTooltipItems: (touchedSpots) {
                            return touchedSpots.map((LineBarSpot touchedSpot) {
                              String label = 'Daily';
                              if (isMonthly) label = 'Total Monthly';
                              if (isYearly) label = 'Total Yearly';
                              
                              return LineTooltipItem(
                                '$label: ${touchedSpot.y.toStringAsFixed(1)} kWh',
                                const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                              );
                            }).toList();
                          },
                        ),
                      ),
                      gridData: FlGridData(
                  show: true,
                  drawVerticalLine: false,
                  getDrawingHorizontalLine: (value) => FlLine(
                    color: UrjaTheme.glassBorder,
                    strokeWidth: 1,
                    dashArray: [5, 5],
                  ),
                ),
                titlesData: FlTitlesData(
                  show: true,
                  rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 30,
                      interval: 1,
                      getTitlesWidget: (value, meta) {
                        if (isYearly) {
                          // Show last 5 years: [Current-4, Current-3, ..., Current]
                          final currentYear = DateTime.now().year;
                          final years = List.generate(5, (index) => (currentYear - 4) + index);
                          
                          if (value.toInt() >= 0 && value.toInt() < years.length) {
                             return Padding(
                               padding: const EdgeInsets.only(top: 8),
                               child: Text(
                                 years[value.toInt()].toString(),
                                 style: const TextStyle(color: UrjaTheme.textSecondary, fontSize: 10),
                               ),
                             );
                          }
                        } else if (isMonthly) {
                           const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                           if (value.toInt() >= 0 && value.toInt() < months.length) {
                             return Padding(
                               padding: const EdgeInsets.only(top: 8),
                               child: Text(
                                 months[value.toInt()],
                                 style: const TextStyle(color: UrjaTheme.textSecondary, fontSize: 10),
                               ),
                             );
                           }
                        } else {
                          const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
                          if (value.toInt() >= 0 && value.toInt() < days.length) {
                            return Padding(
                              padding: const EdgeInsets.only(top: 8),
                              child: Text(
                                days[value.toInt()],
                                style: const TextStyle(color: UrjaTheme.textSecondary, fontSize: 12),
                              ),
                            );
                          }
                        }
                        return const Text('');
                      },
                    ),
                  ),
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                        showTitles: true,
                        interval: maxY / 5, // Dynamic interval based on max Y
                        reservedSize: 40, // Increased reserved size
                        getTitlesWidget: (value, meta) {
                          if (value == 0) return const Text(''); // Hide 0 if needed
                          return Text(
                            value >= 1000 ? '${(value/1000).toStringAsFixed(1)}k' : value.toInt().toString(),
                            style: const TextStyle(color: UrjaTheme.textSecondary, fontSize: 10),
                          );
                        },
                      ),
                  ),
                ),
                borderData: FlBorderData(show: false),
                minX: 0,
                maxX: maxX,
                minY: 0,
                maxY: maxY,
                lineBarsData: [
                  LineChartBarData(
                    spots: displayData
                        .asMap()
                        .entries
                        .map((e) => FlSpot(e.key.toDouble(), e.value))
                        .toList(),
                    isCurved: true,
                    gradient: const LinearGradient(
                      colors: [UrjaTheme.primaryGreen, UrjaTheme.accentCyan],
                    ),
                    barWidth: 3,
                    isStrokeCapRound: true,
                    dotData: const FlDotData(show: false),
                    belowBarData: BarAreaData(
                      show: true,
                      gradient: LinearGradient(
                        colors: [
                          UrjaTheme.primaryGreen.withValues(alpha: 0.3),
                          UrjaTheme.primaryGreen.withValues(alpha: 0.0),
                        ],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// 4. Consumption Breakdown (Donut Chart)
class ConsumptionBreakdownChart extends StatelessWidget {
  const ConsumptionBreakdownChart({super.key});

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Breakdown in kW', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 24),
          SizedBox(
            height: 200,
            child: PieChart(
              PieChartData(
                sectionsSpace: 4,
                centerSpaceRadius: 40,
                sections: [
                  PieChartSectionData(
                    color: UrjaTheme.primaryGreen,
                    value: 40,
                    title: '40%',
                    radius: 50,
                    titleStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                  PieChartSectionData(
                    color: const Color(0xFF14B8A6), // Teal
                    value: 30,
                    title: '30%',
                    radius: 50,
                    titleStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                  PieChartSectionData(
                    color: const Color(0xFF0EA5E9), // Sky Blue
                    value: 15,
                    title: '15%',
                    radius: 50,
                    titleStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                  PieChartSectionData(
                    color: UrjaTheme.glassBorder,
                    value: 15,
                    title: '15%',
                    radius: 50,
                    titleStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          _buildLegendItem(context, 'HVAC', UrjaTheme.primaryGreen),
          _buildLegendItem(context, 'Lighting', const Color(0xFF14B8A6)),
          _buildLegendItem(context, 'Appliances', const Color(0xFF0EA5E9)),
          _buildLegendItem(context, 'Others', UrjaTheme.glassBorder),
        ],
      ),
    );
  }

  Widget _buildLegendItem(BuildContext context, String label, Color color) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Container(width: 12, height: 12, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
          const SizedBox(width: 8),
          Text(label, style: Theme.of(context).textTheme.bodyMedium),
        ],
      ),
    );
  }
}

// 5. Smart Hub Card (Slider)
class SmartHubCard extends StatelessWidget {
  final double currentLimit;
  final Function(double) onLimitChanged;

  const SmartHubCard({
    super.key,
    required this.currentLimit,
    required this.onLimitChanged,
  });

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('KW Limit', style: Theme.of(context).textTheme.titleLarge),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: UrjaTheme.primaryGreen.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: UrjaTheme.primaryGreen.withValues(alpha: 0.2)),
                ),
                child: Text(
                  '${currentLimit.toInt()} kW',
                  style: const TextStyle(color: UrjaTheme.primaryGreen, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              activeTrackColor: UrjaTheme.primaryGreen,
              inactiveTrackColor: UrjaTheme.glassBorder,
              thumbColor: Colors.white,
              trackHeight: 6,
              overlayColor: UrjaTheme.primaryGreen.withValues(alpha: 0.2),
            ),
            child: Slider(
              value: currentLimit,
              min: 0,
              max: 500,
              onChanged: onLimitChanged,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Set your daily consumption limit to receive alerts.',
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ],
      ),
    );
  }
}

// 6. AI Insights Card
class AiInsightsCard extends StatelessWidget {
  const AiInsightsCard({super.key});

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF6366F1), Color(0xFFA855F7)]),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Icon(Icons.auto_awesome, color: Colors.white),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'AI Insight',
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        color: const Color(0xFFA855F7),
                        fontWeight: FontWeight.bold,
                      ),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Reduce HVAC usage by 10% during peak hours to save ₹450/month.',
                  style: TextStyle(fontSize: 13),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// 7. Leaderboard Card (Right Panel)
class LeaderboardCard extends StatelessWidget {
  const LeaderboardCard({super.key});

  @override
  Widget build(BuildContext context) {
    final leaders = [
      {'name': 'Sharma Villa', 'score': '98%', 'rank': 1, 'avatar': 'S'},
      {'name': 'Green House', 'score': '95%', 'rank': 2, 'avatar': 'G'},
      {'name': 'Your Home', 'score': '92%', 'rank': 3, 'avatar': 'Y'},
      {'name': 'Blue Sky', 'score': '88%', 'rank': 4, 'avatar': 'B'},
    ];

    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Neighborhood Leaderboard', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 24),
          ...leaders.map((leader) => Padding(
                padding: const EdgeInsets.only(bottom: 16),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 20,
                      backgroundColor: UrjaTheme.glassBorder,
                      child: Text(
                        leader['avatar'] as String,
                        style: const TextStyle(color: Colors.white),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            leader['name'] as String,
                            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                  fontWeight: FontWeight.w600,
                                  color: leader['name'] == 'Your Home' ? UrjaTheme.primaryGreen : null,
                                ),
                          ),
                          Text(
                            'Rank #${leader['rank']}',
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: UrjaTheme.primaryGreen.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        leader['score'] as String,
                        style: const TextStyle(color: UrjaTheme.primaryGreen, fontWeight: FontWeight.bold, fontSize: 12),
                      ),
                    ),
                  ],
                ),
              )),
        ],
      ),
    );
  }
}
