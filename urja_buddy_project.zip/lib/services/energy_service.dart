import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/energy_data.dart';
import '../models/appliance.dart';

class EnergyService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Stream for live usage updates (returns EnergyData model)
  Stream<EnergyData> get energyDataStream {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      return Stream.value(EnergyData.initial());
    }

    final liveDocRef = _firestore
        .collection('users')
        .doc(user.uid)
        .collection('energy_data')
        .doc('live');

    final dailyLogsRef = _firestore
        .collection('users')
        .doc(user.uid)
        .collection('energy_data')
        .doc('live')
        .collection('daily_logs');

    // Combine streams: Listen to both Live Doc and Daily Logs
    // Note: Since we don't have RxDart, we use a custom merger
    return _combineStreams(liveDocRef, dailyLogsRef);
  }

  Stream<EnergyData> _combineStreams(DocumentReference liveDocRef, CollectionReference dailyLogsRef) async* {
    // Helper to calculate start of current week (Monday)
    DateTime now = DateTime.now();
    
    // --- WEEKLY Logic ---
    DateTime startOfWeek = now.subtract(Duration(days: now.weekday - 1));
    DateTime startOfQuery = DateTime(startOfWeek.year, startOfWeek.month, startOfWeek.day);
    DateTime endOfWeek = startOfWeek.add(const Duration(days: 7));
    DateTime endOfQuery = DateTime(endOfWeek.year, endOfWeek.month, endOfWeek.day);

    // --- MONTHLY Logic ---
    // Start of current year to cover Jan-Dec
    DateTime startOfYear = DateTime(now.year, 1, 1);
    DateTime endOfYear = DateTime(now.year + 1, 1, 1);

    // --- YEARLY Logic ---
    // Start of current 5-year block (e.g., 2022-2026)
    final currentYear = now.year;
    final startOfFiveYears = DateTime(currentYear - 4, 1, 1);
    final endOfFiveYears = DateTime(currentYear + 1, 1, 1);

    // Fetch logs covering the widest range (Yearly: last 5 years)
    final logsStream = dailyLogsRef
        .where('date', isGreaterThanOrEqualTo: Timestamp.fromDate(startOfFiveYears))
        .where('date', isLessThan: Timestamp.fromDate(endOfFiveYears))
        .orderBy('date')
        .snapshots();

    await for (final logsSnapshot in logsStream) {
       final liveSnapshot = await liveDocRef.get(); // Fetch latest live data
       
       if (!liveSnapshot.exists || liveSnapshot.data() == null) {
         yield EnergyData.initial();
         continue;
       }

       final liveData = liveSnapshot.data() as Map<String, dynamic>;
       
       // 1. Process Weekly Trend [Mon-Sun]
       List<double> weeklyTrend = List.filled(7, 0.0);
       
       // 2. Process Monthly Trend [Jan-Dec]
       List<double> monthlyTrend = List.filled(12, 0.0);
       
       // 3. Process Yearly Trend [Year-4 ... Year] (5 years)
       List<double> yearlyTrend = List.filled(5, 0.0);

       for (var doc in logsSnapshot.docs) {
         final data = doc.data() as Map<String, dynamic>;
         final timestamp = data['date'] as Timestamp;
         final date = timestamp.toDate();
         final kwh = (data['kwh'] as num?)?.toDouble() ?? 0.0;
         
         // A. Weekly Mapping
         // Check if date is in current week window
         if (date.isAfter(startOfQuery.subtract(const Duration(seconds: 1))) && 
             date.isBefore(endOfQuery)) {
            int dayIndex = date.weekday - 1; // 0=Mon
            if (dayIndex >= 0 && dayIndex < 7) {
               weeklyTrend[dayIndex] = kwh;
            }
         }

         // B. Monthly Mapping
         // Check if date is in current year
         if (date.year == now.year) {
           int monthIndex = date.month - 1; // 0=Jan, 11=Dec
           if (monthIndex >= 0 && monthIndex < 12) {
             monthlyTrend[monthIndex] += kwh; // Aggregate daily totals into month
           }
         }
         
         // C. Yearly Mapping
         // Check if date is in the 5-year window
         int yearDiff = date.year - (currentYear - 4); // 2022 - (2026-4) = 0
         if (yearDiff >= 0 && yearDiff < 5) {
           yearlyTrend[yearDiff] += kwh;
         }
       }

       // Create EnergyData with ALL trends populated
       yield EnergyData.fromMap(liveData).copyWith(
         weeklyTrend: weeklyTrend,
         monthlyTrend: monthlyTrend,
         yearlyTrend: yearlyTrend,
       );
    }
  }

  String _getDayName(int index) {
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    if (index >= 0 && index < days.length) return days[index];
    return 'Unknown';
  }

  String _getTodayDateId() {
    final now = DateTime.now();
    return "${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}";
  }

  // Legacy Stream for specific widgets if needed (optional)
  Stream<Map<String, dynamic>> get liveUsageStream {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      // Return default/empty stream if no user is logged in
      return Stream.value({
        'current_kwh': 20.0,
        'daily_usage': 12.5,
        'status': 'Online',
      });
    }

    return _firestore
        .collection('users')
        .doc(user.uid)
        .collection('energy_data')
        .doc('live')
        .snapshots()
        .map((snapshot) {
      if (snapshot.exists && snapshot.data() != null) {
        final data = snapshot.data()!;
        return {
          'current_kwh': (data['current_kwh'] as num?)?.toDouble() ?? 20.0,
          'daily_usage': (data['daily_usage'] as num?)?.toDouble() ?? 12.5,
          'status': data['status'] as String? ?? 'Online',
        };
      }
      return {
        'current_kwh': 20.0,
        'daily_usage': 12.5,
        'status': 'Online',
      };
    });
  }

  // Add Appliance and Update Stats
  Future<void> addAppliance(Appliance app) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) throw Exception('User not logged in');

    // 1. Save to sub-collection
    await _firestore
        .collection('users')
        .doc(user.uid)
        .collection('appliances')
        .doc(app.id)
        .set(app.toMap());

    // 2. Calculate daily consumption in kWh
    final dailyKwh = (app.wattage * app.hoursPerDay) / 1000;

    // 3. Update global energy stats
    final liveDocRef = _firestore
        .collection('users')
        .doc(user.uid)
        .collection('energy_data')
        .doc('live');

    final todayDateId = _getTodayDateId();
    final dailyLogRef = liveDocRef.collection('daily_logs').doc(todayDateId);

    await _firestore.runTransaction((transaction) async {
      final liveSnapshot = await transaction.get(liveDocRef);
      final dailyLogSnapshot = await transaction.get(dailyLogRef);

      // A. Update Daily Log (The source of truth for the graph)
      if (!dailyLogSnapshot.exists) {
        transaction.set(dailyLogRef, {
          'date': Timestamp.fromDate(DateTime.now()), // Save actual date
          'kwh': dailyKwh,
        });
      } else {
        transaction.update(dailyLogRef, {
          'kwh': FieldValue.increment(dailyKwh),
        });
      }

      // B. Update Live Aggregate (for total cost/usage)
      if (!liveSnapshot.exists) {
        transaction.set(liveDocRef, {
          'current_kwh': dailyKwh,
          'daily_usage': dailyKwh, // Reset daily usage logic might be needed elsewhere, but for now strict increment
          'budget_limit': 250.0,
          'status': 'Online',
          'last_updated': FieldValue.serverTimestamp(),
        });
      } else {
        transaction.update(liveDocRef, {
          'current_kwh': FieldValue.increment(dailyKwh),
          'daily_usage': FieldValue.increment(dailyKwh), // This is "Total Daily" across all days if not reset? 
          // Actually, daily_usage usually resets at midnight. 
          // For now, we increment it to reflect "usage added today".
          'last_updated': FieldValue.serverTimestamp(),
        });
      }
    });
  }

  // Save manual meter reading
  Future<void> saveMeterReading({
    required double previousReading,
    required double currentReading,
  }) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) throw Exception('User not logged in');

    if (currentReading < previousReading) {
      throw Exception('Current reading cannot be lower than previous');
    }

    final usage = currentReading - previousReading;
    
    // Update the live doc
    await _firestore
        .collection('users')
        .doc(user.uid)
        .collection('energy_data')
        .doc('live')
        .set({
      'current_kwh': usage,
      'previous_reading': previousReading,
      'current_reading': currentReading,
      'last_updated': FieldValue.serverTimestamp(),
      'source': 'manual_meter',
    }, SetOptions(merge: true));
  }

  // Update kWh from CSV Upload
  Future<void> updateKwhFromCsv(double totalKwh) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) throw Exception('User not logged in');

    await _firestore
        .collection('users')
        .doc(user.uid)
        .collection('energy_data')
        .doc('live')
        .set({
      'current_kwh': totalKwh,
      'last_updated': FieldValue.serverTimestamp(),
      'source': 'csv_upload',
    }, SetOptions(merge: true));
  }

  // Update Budget Limit
  Future<void> updateBudgetLimit(double newLimit) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) throw Exception('User not logged in');

    await _firestore
        .collection('users')
        .doc(user.uid)
        .collection('energy_data')
        .doc('live')
        .set({
      'budget_limit': newLimit,
      'last_updated': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  // Simulate Smart Plug Connection
  Future<double> connectSmartDevice(String deviceName) async {
    // Simulate network delay
    await Future.delayed(const Duration(seconds: 2));
    
    // Return a random "live" wattage between 50W and 2000W
    // In a real app, this would connect to Tuya/Shelly API
    return (50 + (DateTime.now().millisecond % 1950)).toDouble();
  }

  // Simulate Live Data for Dashboard
  // DEPRECATED: Removed to force real stream usage
  // Future<void> simulateLiveData() async { ... }
}
