class ApiKeys {
  // Ideally, this should be fetched from a secure config or environment variable.
  // For this implementation, we are encapsulating it here.
  static const String geminiApiKey = 'gen-lang-client-0263141973';
}
