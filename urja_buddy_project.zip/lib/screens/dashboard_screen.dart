import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../widgets/dashboard_widgets.dart';
import '../models/energy_data.dart';
import '../services/energy_service.dart';
import '../widgets/appliance_manager_card.dart';
import '../providers/energy_provider.dart';
// import 'analytics_screen.dart'; // Import for ApplianceManager related logic if needed

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final asyncData = ref.watch(energyProvider);
    final isLargeDesktop = MediaQuery.of(context).size.width > 1200;

    return asyncData.when(
      loading: () => const Center(child: CircularProgressIndicator(color: Colors.green)),
      error: (err, stack) => Center(child: Text('Error loading data: $err', style: const TextStyle(color: Colors.red))),
      data: (data) {
        return SingleChildScrollView(
          padding: const EdgeInsets.all(32),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header Metrics
              _buildMetricsRow(context, data),
              const SizedBox(height: 32),

              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Main Content Column
                  Expanded(
                    flex: 3,
                    child: Column(
                      children: [
                        // Main Graph
                        ConsumptionTrendChart(
                          weeklyData: data.weeklyTrend, 
                          monthlyData: data.monthlyTrend,
                          yearlyData: data.yearlyTrend,
                          todayTotalOverride: data.todayKWh, // Force today's total
                        ),
                        const SizedBox(height: 32),

                        // Smart Hub & Breakdown
                        _buildSecondaryRow(context, data, ref),
                        const SizedBox(height: 32),
                        
                        // AI Insights
                        const AiInsightsCard(),
                        const SizedBox(height: 32),

                        // Appliance Manager (Moved from Analytics)
                        const ApplianceManagerCard(),
                      ],
                    ),
                  ),
                  
                  // Right Panel (Leaderboard) - Only on Large Desktop
                  if (isLargeDesktop) ...[
                    const SizedBox(width: 32),
                    const Expanded(
                      flex: 1,
                      child: Column(
                        children: [
                          LeaderboardCard(),
                          // Add more right panel widgets here if needed
                        ],
                      ),
                    ),
                  ],
                ],
              ),

              // Leaderboard for smaller screens
              if (!isLargeDesktop) ...[
                const SizedBox(height: 32),
                const LeaderboardCard(),
              ],
            ],
          ),
        );
      },
    );
  }

  Widget _buildMetricsRow(BuildContext context, EnergyData data) {
    // Responsive Grid for Metrics
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;
        final isMobile = width < 700;
        
        final metrics = [
          MetricCard(
            title: "Today's Usage",
            value: '${data.todayKWh.toStringAsFixed(1)} kWh', // Fixed to show unit
            subValue: '-12%',
            isPositive: true,
            icon: Icons.electric_bolt_rounded,
          ),
          MetricCard(
            title: 'Monthly Cost',
            value: '₹${(data.currentKWh * 8.5).toStringAsFixed(0)}', // Updated rate to 8.5
            subValue: '-5%',
            isPositive: true,
            icon: Icons.currency_rupee_rounded,
          ),
        ];

        if (isMobile) {
          return Column(
            children: metrics
                .map((m) => Padding(padding: const EdgeInsets.only(bottom: 16), child: m))
                .toList(),
          );
        }

        return Row(
          children: metrics.map((m) => Expanded(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 8), child: m))).toList(),
        );
      },
    );
  }

  Widget _buildSecondaryRow(BuildContext context, EnergyData data, WidgetRef ref) {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth < 900) {
          return Column(
            children: [
              SmartHubCard(
                currentLimit: data.budgetLimit,
                onLimitChanged: (val) {
                  EnergyService().updateBudgetLimit(val);
                },
              ),
              const SizedBox(height: 32),
              const ConsumptionBreakdownChart(),
            ],
          );
        }
        
        return Row(
          children: [
            Expanded(
              child: SmartHubCard(
                currentLimit: data.budgetLimit,
                onLimitChanged: (val) {
                  EnergyService().updateBudgetLimit(val);
                },
              ),
            ),
            const SizedBox(width: 32),
            const Expanded(child: ConsumptionBreakdownChart()),
          ],
        );
      },
    );
  }
}
