import 'package:flutter/material.dart';
import '../theme/urja_theme.dart';
import '../widgets/dashboard_widgets.dart';
import '../services/auth_service.dart';
import 'login_screen.dart';
import '../core/auth_wrapper.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final AuthService _authService = AuthService();
  bool _notificationsEnabled = true;
  bool _darkMode = true;
  bool _dataSaver = false;

  @override
  Widget build(BuildContext context) {
    final user = _authService.currentUser;
    final email = user?.email ?? 'user@example.com';
    final name = user?.displayName ?? 'Urja User';

    return SingleChildScrollView(
      padding: const EdgeInsets.all(32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Settings', style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 32),
          
          // Profile Section
          GlassCard(
            child: Row(
              children: [
                const CircleAvatar(
                  radius: 30,
                  backgroundColor: UrjaTheme.primaryGreen,
                  child: Text('U', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white)),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(name, style: Theme.of(context).textTheme.titleLarge),
                      Text(email, style: Theme.of(context).textTheme.bodyMedium),
                    ],
                  ),
                ),
                OutlinedButton(
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Profile editing coming soon!')));
                  },
                  style: OutlinedButton.styleFrom(
                    foregroundColor: UrjaTheme.primaryGreen,
                    side: const BorderSide(color: UrjaTheme.primaryGreen),
                  ),
                  child: const Text('Edit'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 32),

          // Preferences
          Text('Preferences', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 16),
          GlassCard(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
            child: Column(
              children: [
                _buildSwitchTile(
                  'Dark Mode',
                  'Use dark theme for better battery life',
                  _darkMode,
                  (val) => setState(() => _darkMode = val),
                  Icons.dark_mode,
                ),
                const Divider(color: UrjaTheme.glassBorder),
                _buildSwitchTile(
                  'Notifications',
                  'Receive alerts about high usage',
                  _notificationsEnabled,
                  (val) => setState(() => _notificationsEnabled = val),
                  Icons.notifications,
                ),
                const Divider(color: UrjaTheme.glassBorder),
                _buildSwitchTile(
                  'Data Saver',
                  'Reduce data usage on mobile networks',
                  _dataSaver,
                  (val) => setState(() => _dataSaver = val),
                  Icons.data_usage,
                ),
              ],
            ),
          ),
          const SizedBox(height: 32),

          // Account Actions
          Text('Account', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 16),
          GlassCard(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.help_outline, color: UrjaTheme.textSecondary),
                  title: const Text('Help & Support', style: TextStyle(color: UrjaTheme.textPrimary)),
                  trailing: const Icon(Icons.arrow_forward_ios, size: 16, color: UrjaTheme.textSecondary),
                  onTap: () {
                     ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Support center opening...')));
                  },
                ),
                const Divider(color: UrjaTheme.glassBorder),
                ListTile(
                  leading: const Icon(Icons.logout, color: UrjaTheme.errorRed),
                  title: const Text('Sign Out', style: TextStyle(color: UrjaTheme.errorRed)),
                  onTap: () async {
                    // Show loading feedback
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Signing out...'),
                        duration: Duration(seconds: 1),
                      ),
                    );
                    
                    try {
                      await _authService.signOut();
                      if (context.mounted) {
                        // Reset app to AuthWrapper to handle login state
                        Navigator.of(context).pushAndRemoveUntil(
                          MaterialPageRoute(builder: (context) => const AuthWrapper()),
                          (route) => false,
                        );
                      }
                    } catch (e) {
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Error signing out: $e')),
                        );
                      }
                    }
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 32),
          Center(
            child: Text(
              'Urja Buddy v1.0.0',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSwitchTile(String title, String subtitle, bool value, Function(bool) onChanged, IconData icon) {
    return SwitchListTile(
      value: value,
      onChanged: onChanged,
      title: Text(title, style: const TextStyle(color: UrjaTheme.textPrimary, fontWeight: FontWeight.bold)),
      subtitle: Text(subtitle, style: const TextStyle(color: UrjaTheme.textSecondary, fontSize: 12)),
      secondary: Icon(icon, color: UrjaTheme.primaryGreen),
      activeColor: UrjaTheme.primaryGreen,
      contentPadding: EdgeInsets.zero,
    );
  }
}
