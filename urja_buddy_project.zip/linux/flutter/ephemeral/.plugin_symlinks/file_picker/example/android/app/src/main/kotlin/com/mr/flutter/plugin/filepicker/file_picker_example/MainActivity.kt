package com.mr.flutter.plugin.filepicker.file_picker_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
